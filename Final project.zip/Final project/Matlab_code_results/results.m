nodes_astar = 59;
nodes_jps = 35;
nodes_bi_jps = 18;

figure;
bar([nodes_astar, nodes_jps, nodes_bi_jps], 'FaceColor', 'r'); 
xlabel('Algorithm');
ylabel('Number of Expanded Nodes');
title('Comparison of Expanded Nodes');
set(gca, 'XTickLabel', {'A*', 'JPS', 'Improved Bidirectional JPS'});


time_astar = 0.000971;
time_jps = 0.000328;
time_bi_jps = 0.000974;

figure;
bar([time_astar, time_jps, time_bi_jps], 'FaceColor', 'y');  
xlabel('Algorithm');
ylabel('Execution Time (s)');
title('Comparison of Execution Time');
set(gca, 'XTickLabel', {'A*', 'JPS', 'Improved Bidirectional JPS'});


turns_astar = 20;
turns_jps = 23;
turns_bi_jps_c = 5;
turns_bi_jps_b = 9;
turns_bi_jps_a = 4;
turns_bi_jps = turns_bi_jps_c + turns_bi_jps_b + turns_bi_jps_a;

figure;
bar([turns_astar, turns_jps, turns_bi_jps], 'FaceColor', 'b'); 
xlabel('Algorithm');
ylabel('Number of Turns');
title('Comparison of Number of Turns');
set(gca, 'XTickLabel', {'A*', 'JPS', 'Improved Bidirectional JPS'});
