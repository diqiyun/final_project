#ifndef CLUSTER_H
#define CLUSTER_H
#include <stdbool.h>
typedef struct {
    int x, y;
} Point;

typedef struct {
    Point* points;
    int size;
    int capacity;
} Cluster;
bool findPointInCluster(Cluster* cluster, Point point);
void initCluster(Cluster* cluster, int capacity);
void addPointToCluster(Cluster* cluster, Point point);
void freeCluster(Cluster* cluster);

#endif