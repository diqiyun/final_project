#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>
#include "map.h"  

typedef struct {
    int x;
    int y;
} Point;

typedef struct Node {
    Point pos;
    struct Node* parent;
    double g;  
    double h;  
    double f;  
} Node;

typedef struct {
    Node* nodes;
    int size;
    int capacity;
} PriorityQueue;


void initQueue(PriorityQueue* queue, int capacity);
void freeQueue(PriorityQueue* queue);
void push(PriorityQueue* queue, Node node);
Node pop(PriorityQueue* queue);
bool isEmpty(PriorityQueue* queue);

double heuristic(Point a, Point b);
bool isInBounds(Point p);
bool jump(Point current, Point direction, Point goal, int map[MAP_SIZE][MAP_SIZE], Point* nextJump, Point* path, int* pathSize);
void getNeighbors(Point p, Point* neighbors, int* count, int map[MAP_SIZE][MAP_SIZE]);
bool jps(int map[MAP_SIZE][MAP_SIZE], Point start, Point goal, Node* resultPath, int* pathSize);

int countTurns(Node* path, int pathSize);

int main() {
    Point start = {29, 0};  
    Point goal = {0, 29};   
    Node resultPath[MAP_SIZE * MAP_SIZE];
    int pathSize = 0;

    clock_t start_time = clock();

    if (jps(map, start, goal, resultPath, &pathSize)) {
        printf("JPS Path found with %d points.\n", pathSize);
        for (int i = pathSize - 1; i >= 0; i--) {
            double centerX = resultPath[i].pos.x + 0.5; 
            double centerY = resultPath[i].pos.y + 0.5; 
            printf("(%.1f, %.1f)\n", centerX, centerY);
        }

        int turnCount = countTurns(resultPath, pathSize);
        printf("Number of turns in the path: %d\n", turnCount);
    } else {
        printf("JPS No path found.\n");
    }


    clock_t end_time = clock();
    double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("JPS Time taken: %.6f seconds\n", elapsed_time);

    return 0;
}


bool jps(int map[MAP_SIZE][MAP_SIZE], Point start, Point goal, Node* resultPath, int* pathSize) {
    PriorityQueue openSet;
    initQueue(&openSet, MAP_SIZE * MAP_SIZE);

    Node startNode = { start, NULL, 0, heuristic(start, goal), 0 };
    push(&openSet, startNode);

    Node* visited = (Node*)calloc(MAP_SIZE * MAP_SIZE, sizeof(Node));
    int visitedSize = 0;

    while (!isEmpty(&openSet)) {
        Node current = pop(&openSet);

        if (current.pos.x == goal.x && current.pos.y == goal.y) {
            Node* node = &current;
            *pathSize = 0;
            while (node != NULL) {
                resultPath[(*pathSize)++] = *node;
                node = node->parent;
            }
            free(visited);
            freeQueue(&openSet);
            return true;
        }

        visited[visitedSize++] = current;

        Point neighbors[8]; // 保持八个方向
        int neighborCount;
        getNeighbors(current.pos, neighbors, &neighborCount, map);

        for (int i = 0; i < neighborCount; i++) {
            Point direction = { neighbors[i].x - current.pos.x, neighbors[i].y - current.pos.y };
            Point jumpPoint;
            Point jumpPath[MAP_SIZE * MAP_SIZE];
            int jumpPathSize = 0;

            if (jump(current.pos, direction, goal, map, &jumpPoint, jumpPath, &jumpPathSize)) {
                bool alreadyVisited = false;
                for (int j = 0; j < visitedSize; j++) {
                    if (visited[j].pos.x == jumpPoint.x && visited[j].pos.y == jumpPoint.y) {
                        alreadyVisited = true;
                        break;
                    }
                }

                if (!alreadyVisited) {
                    for (int k = 0; k < jumpPathSize; k++) {
                        resultPath[(*pathSize)++] = (Node){jumpPath[k], &visited[visitedSize - 1], 0, 0, 0};
                    }

                    Node* newNode = (Node*)malloc(sizeof(Node));
                    *newNode = (Node){ jumpPoint, &visited[visitedSize - 1], current.g + jumpPathSize, heuristic(jumpPoint, goal), 0 };
                    newNode->f = newNode->g + newNode->h;
                    push(&openSet, *newNode);
                    free(newNode); 
                }
            }
        }
    }

    free(visited);
    freeQueue(&openSet);
    return false;
}

void getNeighbors(Point p, Point* neighbors, int* count, int map[MAP_SIZE][MAP_SIZE]) {
    *count = 0;
    Point possibleNeighbors[8] = {
        {p.x - 1, p.y}, {p.x + 1, p.y}, {p.x, p.y - 1}, {p.x, p.y + 1},
        {p.x - 1, p.y - 1}, {p.x + 1, p.y + 1}, {p.x - 1, p.y + 1}, {p.x + 1, p.y - 1}
    };
    for (int i = 0; i < 8; i++) {
        if (isInBounds(possibleNeighbors[i]) && map[possibleNeighbors[i].x][possibleNeighbors[i].y] == 0) {
            neighbors[(*count)++] = possibleNeighbors[i];
        }
    }
}

// JPS
bool jump(Point current, Point direction, Point goal, int map[MAP_SIZE][MAP_SIZE], Point* nextJump, Point* path, int* pathSize) {
    Point next = {current.x + direction.x, current.y + direction.y};

    while (isInBounds(next) && map[next.x][next.y] == 0) {
        path[(*pathSize)++] = next;  

        if (next.x == goal.x && next.y == goal.y) {
            *nextJump = next;
            return true;
        }

        if (direction.x != 0 && direction.y != 0) {  // diagnal
            if ((isInBounds((Point){next.x - direction.x, next.y}) && map[next.x - direction.x][next.y] == 1) ||
                (isInBounds((Point){next.x, next.y - direction.y}) && map[next.x][next.y - direction.y] == 1)) {
                *nextJump = next;
                return true;
            }
            if (jump(next, (Point){direction.x, 0}, goal, map, nextJump, path, pathSize) || 
                jump(next, (Point){0, direction.y}, goal, map, nextJump, path, pathSize)) {
                *nextJump = next;
                return true;
            }
        } else {  // 非对角线
            if (direction.x != 0) {
                if ((isInBounds((Point){next.x, next.y - 1}) && map[next.x][next.y - 1] == 0 && map[current.x][current.y - 1] == 1) ||
                    (isInBounds((Point){next.x, next.y + 1}) && map[next.x][next.y + 1] == 0 && map[current.x][current.y + 1] == 1)) {
                    *nextJump = next;
                    return true;
                }
            } else if (direction.y != 0) {
                if ((isInBounds((Point){next.x - 1, next.y}) && map[next.x - 1][next.y] == 0 && map[current.x - 1][current.y] == 1) ||
                    (isInBounds((Point){next.x + 1, next.y}) && map[next.x + 1][next.y] == 0 && map[current.x + 1][current.y] == 1)) {
                    *nextJump = next;
                    return true;
                }
            }
        }

        next.x += direction.x;
        next.y += direction.y;
    }

    return false;
}

// manhattan discan
double heuristic(Point a, Point b) {
    return abs(a.x - b.x) + abs(a.y - b.y);
}

bool isInBounds(Point p) {
    return p.x >= 0 && p.x < MAP_SIZE && p.y >= 0 && p.y < MAP_SIZE;
}

int countTurns(Node* path, int pathSize) {
    if (pathSize < 3) return 0; 

    int turnCount = 0;
    for (int i = pathSize - 1; i > 1; i--) {
        Point prev = path[i].pos;
        Point curr = path[i - 1].pos;
        Point next = path[i - 2].pos;

        int dx1 = curr.x - prev.x;
        int dy1 = curr.y - prev.y;
        int dx2 = next.x - curr.x;
        int dy2 = next.y - curr.y;

        if (dx1 != dx2 || dy1 != dy2) {
            turnCount++;
        }
    }

    return turnCount;
}


void initQueue(PriorityQueue* queue, int capacity) {
    queue->nodes = (Node*)malloc(capacity * sizeof(Node));
    queue->size = 0;
    queue->capacity = capacity;
}

void freeQueue(PriorityQueue* queue) {
    if (queue->nodes != NULL) {
        free(queue->nodes);
        queue->nodes = NULL;
    }
    queue->size = 0;
    queue->capacity = 0;
}

void push(PriorityQueue* queue, Node node) {
    if (queue->size < queue->capacity) {
        queue->nodes[queue->size++] = node;
    }
}

Node pop(PriorityQueue* queue) {
    int minIndex = 0;
    for (int i = 1; i < queue->size; i++) {
        if (queue->nodes[i].f < queue->nodes[minIndex].f) {
            minIndex = i;
        }
    }
    Node result = queue->nodes[minIndex];
    queue->nodes[minIndex] = queue->nodes[--queue->size];
    return result;
}

bool isEmpty(PriorityQueue* queue) {
    return queue->size == 0;
}
