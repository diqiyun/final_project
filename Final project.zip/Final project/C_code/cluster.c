#include <stdlib.h>
#include "cluster.h"
#include <stdio.h>
#include <stdbool.h>

bool findPointInCluster(Cluster* cluster, Point point) {
    for (int i = 0; i < cluster->size; i++) {
        if (cluster->points[i].x == point.x && cluster->points[i].y == point.y) {
            return true;
        }
    }
    return false;
}
void initCluster(Cluster* cluster, int capacity) {
    cluster->points = (Point*)malloc(capacity * sizeof(Point));
    cluster->size = 0;
    cluster->capacity = capacity;
}

void addPointToCluster(Cluster *cluster, Point p) {
    if (cluster->size >= cluster->capacity) {
        cluster->capacity *= 2;
        cluster->points = realloc(cluster->points, cluster->capacity * sizeof(Point));
        if (cluster->points == NULL) {
            fprintf(stderr, "Memory allocation failed!\n");
            exit(EXIT_FAILURE);
        }
    }
    cluster->points[cluster->size++] = p;
}


void freeCluster(Cluster* cluster) {
    if (cluster->points != NULL) {
        free(cluster->points);
        cluster->points = NULL; 
    }
    cluster->size = 0;
    cluster->capacity = 0;
}
