#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>
#include "map.h"  

typedef struct {
    int x;
    int y;
} Point;

typedef struct Node {
    Point pos;
    struct Node* parent;
    double g;  
    double h;  
    double f;  
} Node;


typedef struct {
    Node* nodes;
    int size;
    int capacity;
} PriorityQueue;


void initQueue(PriorityQueue* queue, int capacity);
void freeQueue(PriorityQueue* queue);
void push(PriorityQueue* queue, Node node);
Node pop(PriorityQueue* queue);
bool isEmpty(PriorityQueue* queue);

double heuristic(Point a, Point b);
bool isInBounds(Point p);
bool aStar(int map[MAP_SIZE][MAP_SIZE], Point start, Point goal, Node* resultPath, int* pathSize);
int countTurns(Node* path, int pathSize);

int main() {
    Point start = {29, 0};  
    Point goal = {0, 29};   
    Node resultPath[MAP_SIZE * MAP_SIZE];
    int pathSize = 0;

    clock_t start_time = clock();

    if (aStar(map, start, goal, resultPath, &pathSize)) {
        printf("A* Path found with %d points.\n", pathSize);
        for (int i = pathSize - 1; i >= 0; i--) {
            printf("(%d, %d)\n", resultPath[i].pos.x, resultPath[i].pos.y);
        }

        int turnCount = countTurns(resultPath, pathSize);
        printf("Number of turns in the path: %d\n", turnCount);
    } else {
        printf("A* No path found.\n");
    }

    clock_t end_time = clock();
    double elapsed_time = (double)(end_time - start_time) / CLOCKS_PER_SEC;
    printf("A* Time taken: %.6f seconds\n", elapsed_time);

    return 0;
}

bool aStar(int map[MAP_SIZE][MAP_SIZE], Point start, Point goal, Node* resultPath, int* pathSize) {
    PriorityQueue openSet;
    initQueue(&openSet, MAP_SIZE * MAP_SIZE);

    Node startNode = { start, NULL, 0, heuristic(start, goal), 0 };
    push(&openSet, startNode);

    Node* visited = (Node*)calloc(MAP_SIZE * MAP_SIZE, sizeof(Node));
    int visitedSize = 0;

    while (!isEmpty(&openSet)) {
        Node current = pop(&openSet);

        if (current.pos.x == goal.x && current.pos.y == goal.y) {
            Node* node = &current;
            *pathSize = 0;
            while (node != NULL) {
                resultPath[(*pathSize)++] = *node;
                node = node->parent;
            }
            free(visited);
            freeQueue(&openSet);
            return true;
        }

        visited[visitedSize++] = current;

        // 获取邻居节点（4方向移动）
        Point neighbors[4] = {
            {current.pos.x + 1, current.pos.y}, {current.pos.x - 1, current.pos.y},
            {current.pos.x, current.pos.y + 1}, {current.pos.x, current.pos.y - 1}
        };

        for (int i = 0; i < 4; i++) {
            Point neighborPos = neighbors[i];
            if (isInBounds(neighborPos) && map[neighborPos.x][neighborPos.y] == 0) {
                bool alreadyVisited = false;
                for (int j = 0; j < visitedSize; j++) {
                    if (visited[j].pos.x == neighborPos.x && visited[j].pos.y == neighborPos.y) {
                        alreadyVisited = true;
                        break;
                    }
                }

                if (!alreadyVisited) {
                    Node neighborNode = { neighborPos, &visited[visitedSize - 1], current.g + 1, heuristic(neighborPos, goal), 0 };
                    neighborNode.f = neighborNode.g + neighborNode.h;
                    push(&openSet, neighborNode);
                }
            }
        }
    }

    free(visited);
    freeQueue(&openSet);
    return false;
}

// basic h（n)
double heuristic(Point a, Point b) {
    return abs(a.x - b.x) + abs(a.y - b.y);
}

bool isInBounds(Point p) {
    return p.x >= 0 && p.x < MAP_SIZE && p.y >= 0 && p.y < MAP_SIZE;
}

int countTurns(Node* path, int pathSize) {
    if (pathSize < 3) return 0; 

    int turnCount = 0;
    for (int i = pathSize - 1; i > 1; i--) {
        Point prev = path[i].pos;
        Point curr = path[i - 1].pos;
        Point next = path[i - 2].pos;

        int dx1 = curr.x - prev.x;
        int dy1 = curr.y - prev.y;
        int dx2 = next.x - curr.x;
        int dy2 = next.y - curr.y;

        // 方向不同转弯
        if (dx1 != dx2 || dy1 != dy2) {
            turnCount++;
        }
    }

    return turnCount;
}

void initQueue(PriorityQueue* queue, int capacity) {
    queue->nodes = (Node*)malloc(capacity * sizeof(Node));
    queue->size = 0;
    queue->capacity = capacity;
}

void freeQueue(PriorityQueue* queue) {
    if (queue->nodes != NULL) {
        free(queue->nodes);
        queue->nodes = NULL;
    }
    queue->size = 0;
    queue->capacity = 0;
}

void push(PriorityQueue* queue, Node node) {
    if (queue->size < queue->capacity) {
        queue->nodes[queue->size++] = node;
    }
}

Node pop(PriorityQueue* queue) {
    int minIndex = 0;
    for (int i = 1; i < queue->size; i++) {
        if (queue->nodes[i].f < queue->nodes[minIndex].f) {
            minIndex = i;
        }
    }
    Node result = queue->nodes[minIndex];
    queue->nodes[minIndex] = queue->nodes[--queue->size];
    return result;
}

bool isEmpty(PriorityQueue* queue) {
    return queue->size == 0;
}
