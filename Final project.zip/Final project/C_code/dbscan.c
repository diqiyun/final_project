#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include "map.h"
#include "cluster.h"

// calculate the distance between two points
double distance(Point a, Point b) {
    return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2));
}

void regionQuery(Point* points, int n, Point p, double eps, bool* neighbors) {
    for (int i = 0; i < n; i++) {
        if (distance(points[i], p) <= eps) {
            neighbors[i] = true;
        }
    }
}

void expandCluster(Point* points, int n, int index, double eps, int minPts, int* clusterId, int currentCluster) {
    bool* neighbors = (bool*)calloc(n, sizeof(bool));
    regionQuery(points, n, points[index], eps, neighbors);

    int neighborCount = 0;
    for (int i = 0; i < n; i++) {
        if (neighbors[i]) neighborCount++;
    }

    if (neighborCount < minPts) {
        clusterId[index] = -1; // noise
    } else {
        clusterId[index] = currentCluster;
        for (int i = 0; i < n; i++) {
            if (neighbors[i] && clusterId[i] == 0) {
                clusterId[i] = currentCluster;
                expandCluster(points, n, i, eps, minPts, clusterId, currentCluster);
            }
        }
    }
    free(neighbors);
}

void dbscan(Point* points, int n, double eps, int minPts, int* clusterId) {
    int currentCluster = 0;
    bool* visited = (bool*)calloc(n, sizeof(bool));

    for (int i = 0; i < n; i++) {
        if (clusterId[i] == 0) {
            visited[i] = true;
            expandCluster(points, n, i, eps, minPts, clusterId, ++currentCluster);
        }
    }

    free(visited);
}

bool identifyAndClusterObstacles(Cluster* clusters, int* numClusters) {
    Point points[MAP_SIZE * MAP_SIZE];
    int pointCount = 0;

    for (int i = 0; i < MAP_SIZE; i++) {
        for (int j = 0; j < MAP_SIZE; j++) {
            if (map[i][j] == 1) {
                points[pointCount++] = (Point){i, j};
            }
        }
    }

    int* clusterId = (int*)calloc(pointCount, sizeof(int));
    dbscan(points, pointCount, 1.5, 3, clusterId);

    int maxClusterId = 0;
    for (int i = 0; i < pointCount; i++) {
        if (clusterId[i] > maxClusterId) {
            maxClusterId = clusterId[i];
        }
    }
    *numClusters = maxClusterId;

    for (int i = 0; i < *numClusters; i++) {
        initCluster(&clusters[i], pointCount);
    }

    for (int i = 0; i < pointCount; i++) {
        if (clusterId[i] > 0) {
            addPointToCluster(&clusters[clusterId[i] - 1], points[i]);
        }
    }

    free(clusterId);
    return true;
}

bool markHotspots(Cluster* clusters, int numClusters) {
    int largestClusterIndex = 0;
    int largestClusterSize = 0;

    // find the biggest cluster
    for (int i = 0; i < numClusters; i++) {
        if (clusters[i].size > largestClusterSize) {
            largestClusterSize = clusters[i].size;
            largestClusterIndex = i;
        }
    }

    Cluster largestCluster = clusters[largestClusterIndex];

    for (int i = 0; i < numClusters; i++) {
        if (i != largestClusterIndex) {
            for (int j = 0; j < clusters[i].size; j++) {
                Point p = clusters[i].points[j];
                map[p.x][p.y] = 1; 
            }
        }
    }

    for (int i = 0; i < largestCluster.size; i++) {
        int x = largestCluster.points[i].x;
        int y = largestCluster.points[i].y;
        map[x][y] = 2; 
    }

    return true;
}

/*
//输出带热点地图时使用
int main() {
    Cluster clusters[MAP_SIZE * MAP_SIZE];
    int numClusters = 0;

    identifyAndClusterObstacles(clusters, &numClusters);
    markHotspots(clusters, numClusters);

    for (int i = 0; i < MAP_SIZE; i++) {
        for (int j = 0; j < MAP_SIZE; j++) {
            printf("%d ", map[i][j]);
        }
        printf("\n");
    }

    for (int i = 0; i < numClusters; i++) {
        freeCluster(&clusters[i]);
    }
}
*/