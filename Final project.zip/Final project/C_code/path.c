#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include "map.h"
#include "cluster.h"
#include "dbscan.h"
#define SAFE_DISTANCE 0.3


typedef struct Node {
    Point pos;
    struct Node* parent;
    double g;
    double h;
    double f;
} Node;

typedef struct {
    Node* nodes;
    int size;
    int capacity;
} PriorityQueue;

void initQueue(PriorityQueue* queue, int capacity) {
    queue->nodes = (Node*)malloc(capacity * sizeof(Node));
    queue->size = 0;
    queue->capacity = capacity;
}

void freeQueue(PriorityQueue* queue) {
    if (queue->nodes != NULL) {
        free(queue->nodes);
        queue->nodes = NULL;
    }
    queue->size = 0;
    queue->capacity = 0;
}


void push(PriorityQueue* queue, Node node) {
    if (queue->size < queue->capacity) {
        queue->nodes[queue->size++] = node;
    }
}

Node pop(PriorityQueue* queue) {
    int minIndex = 0;
    for (int i = 1; i < queue->size; i++) {
        if (queue->nodes[i].f < queue->nodes[minIndex].f) {
            minIndex = i;
        }
    }
    Node result = queue->nodes[minIndex];
    queue->nodes[minIndex] = queue->nodes[--queue->size];
    return result;
}

bool isEmpty(PriorityQueue* queue) {
    return queue->size == 0;
}

double heuristic(Point a, Point b) {
    int dx = abs(a.x - b.x);
    int dy = abs(a.y - b.y);


    // Manhattan distance
    double base_cost = dx + dy;

    // Increase the cost of traversing hotspots
    double hotspot_cost = 0.0;
    int steps = fmax(dx, dy);
    double cost_per_hotspot = 10; // adjust

    for (int i = 0; i <= steps; i++) {
    double t = fmin(fmax((double)i / steps, 0.0), 1.0); 
    int interp_x = a.x + t * (b.x - a.x);
    int interp_y = a.y + t * (b.y - a.y);

    // check boundary
    if (interp_x >= 0 && interp_x < MAP_SIZE && interp_y >= 0 && interp_y < MAP_SIZE) {
        if (map[interp_x][interp_y] == 2) {
            hotspot_cost += cost_per_hotspot;
        }
    } else {
        printf("Warning: Interpolation out of bounds at (%d, %d)\n", interp_x, interp_y);
    }

}
    return base_cost + hotspot_cost;
}

bool isInBounds(Point p) {
    return p.x >= 0 && p.x < MAP_SIZE && p.y >= 0 && p.y < MAP_SIZE;
}

Node* findNodeInList(Point p, Node* list, int listSize) {
    for (int i = 0; i < listSize; i++) {
        if (list[i].pos.x == p.x && list[i].pos.y == p.y) {
            return &list[i];
        }
    }
    return NULL;
}

void getNeighbors(Point p, Point* neighbors, int* count, int map[MAP_SIZE][MAP_SIZE]) {
    *count = 0;
    Point possibleNeighbors[8] = {
        {p.x - 1, p.y}, {p.x + 1, p.y}, {p.x, p.y - 1}, {p.x, p.y + 1},
        {p.x - 1, p.y - 1}, {p.x + 1, p.y + 1}, {p.x - 1, p.y + 1}, {p.x + 1, p.y - 1}
    };
    for (int i = 0; i < 8; i++) {
        if (isInBounds(possibleNeighbors[i]) && map[possibleNeighbors[i].x][possibleNeighbors[i].y] == 0) {
            neighbors[(*count)++] = possibleNeighbors[i];
        }
    }
}

bool jump(Point current, Point direction, Point goal, int map[MAP_SIZE][MAP_SIZE], Point* nextJump) {
    Point next = {current.x + direction.x, current.y + direction.y};
    //printf("Jumping from (%d, %d) to (%d, %d) in direction (%d, %d)\n", current.x, current.y, next.x, next.y, direction.x, direction.y);

    if (!isInBounds(next) || map[next.x][next.y] == 1) {
        return false;
    }

    if (next.x == goal.x && next.y == goal.y) {
        *nextJump = next;
        return true;
    }

    if (direction.x != 0 && direction.y != 0) {
        if ((isInBounds((Point){next.x - direction.x, next.y}) && map[next.x - direction.x][next.y] == 1) ||
            (isInBounds((Point){next.x, next.y - direction.y}) && map[next.x][next.y - direction.y] == 1)) {
            *nextJump = next;
            return true;
        }
        if (jump(next, (Point){direction.x, 0}, goal, map, nextJump) || 
            jump(next, (Point){0, direction.y}, goal, map, nextJump)) {
            *nextJump = next;
            return true;
        }
    } else {
        if (direction.x != 0) {
            if ((isInBounds((Point){next.x, next.y - 1}) && map[next.x][next.y - 1] == 0 && map[current.x][current.y - 1] == 1) ||
                (isInBounds((Point){next.x, next.y + 1}) && map[next.x][next.y + 1] == 0 && map[current.x][current.y + 1] == 1)) {
                *nextJump = next;
                return true;
            }
        } else if (direction.y != 0) {
            if ((isInBounds((Point){next.x - 1, next.y}) && map[next.x - 1][next.y] == 0 && map[current.x - 1][current.y] == 1) ||
                (isInBounds((Point){next.x + 1, next.y}) && map[next.x + 1][next.y] == 0 && map[current.x + 1][current.y] == 1)) {
                *nextJump = next;
                return true;
            }
        }
    }

    return jump(next, direction, goal, map, nextJump);
}

void mergePaths(Node* intersectNode, Node* fromStart, Node* fromGoal, Cluster* path) {
    Node* current = fromStart;
    printf("Merging path from start to intersection:\n");
    while (current != NULL) {
        
        if (!findPointInCluster(path, current->pos)) {
            addPointToCluster(path, current->pos);
        }
        current = current->parent;
    }

    if (!findPointInCluster(path, intersectNode->pos)) {
        
        addPointToCluster(path, intersectNode->pos);
    }

    current = fromGoal;
    printf("Merging path from intersection to goal:\n");
    while (current != NULL) {
        
        if (!findPointInCluster(path, current->pos)) {
            addPointToCluster(path, current->pos);
        }
        current = current->parent;
    }
}

void adjustPathAwayFromObstacles(Cluster* path, int map[MAP_SIZE][MAP_SIZE]) {
    for (int i = 0; i < path->size; i++) {
        Point p = path->points[i];

        bool nearObstacle = false;
        Point offset = {0, 0};

        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue;

                int nx = p.x + dx;
                int ny = p.y + dy;

                if (isInBounds((Point){nx, ny}) && map[nx][ny] == 1) {
                    nearObstacle = true;
                    // 记录方向，用于调整
                    offset.x += dx;
                    offset.y += dy;
                }
            }
        }

        if (nearObstacle) {
            // 计算调整方向的单位向量
            double length = sqrt(offset.x * offset.x + offset.y * offset.y);
            if (length > 0) {
                offset.x = (offset.x / length) * SAFE_DISTANCE;
                offset.y = (offset.y / length) * SAFE_DISTANCE;

                // 调整路径点，使其远离障碍物
                path->points[i].x += offset.x;
                path->points[i].y += offset.y;
            }
        }
    }
}


bool bidirectionalJPS(int map[MAP_SIZE][MAP_SIZE], Point start, Point goal, Cluster* path) {
    PriorityQueue openStart, openGoal;
    initQueue(&openStart, MAP_SIZE * MAP_SIZE);
    initQueue(&openGoal, MAP_SIZE * MAP_SIZE);

    Node startNode = { start, NULL, 0, heuristic(start, goal), 0 };
    Node goalNode = { goal, NULL, 0, heuristic(goal, start), 0 };

    push(&openStart, startNode);
    push(&openGoal, goalNode);

    Node* visitedStart = (Node*)calloc(MAP_SIZE * MAP_SIZE, sizeof(Node));
    Node* visitedGoal = (Node*)calloc(MAP_SIZE * MAP_SIZE, sizeof(Node));
    int visitedStartSize = 0, visitedGoalSize = 0;

    while (!isEmpty(&openStart) && !isEmpty(&openGoal)) {
        Node currentStart = pop(&openStart);
        Node currentGoal = pop(&openGoal);

        visitedStart[visitedStartSize++] = currentStart;
        visitedGoal[visitedGoalSize++] = currentGoal;

        Node* intersectNodeFromStart = findNodeInList(currentStart.pos, visitedGoal, visitedGoalSize);
        Node* intersectNodeFromGoal = findNodeInList(currentGoal.pos, visitedStart, visitedStartSize);

        if (intersectNodeFromStart && !(currentStart.pos.x == start.x && currentStart.pos.y == start.y) &&
            !(currentStart.pos.x == goal.x && currentStart.pos.y == goal.y)) {
            printf("Intersection found at: (%d, %d) from start\n", currentStart.pos.x, currentStart.pos.y);
            mergePaths(intersectNodeFromStart, &currentStart, intersectNodeFromStart, path);
            adjustPathAwayFromObstacles(path, map); // 调整路径点远离障碍物
            free(visitedStart);
            free(visitedGoal);
            freeQueue(&openStart);
            freeQueue(&openGoal);
            return true;
        }

        if (intersectNodeFromGoal && !(currentGoal.pos.x == start.x && currentGoal.pos.y == start.y) &&
            !(currentGoal.pos.x == goal.x && currentGoal.pos.y == goal.y)) {
            printf("Intersection found at: (%d, %d) from goal\n", currentGoal.pos.x, currentGoal.pos.y);
            mergePaths(intersectNodeFromGoal, intersectNodeFromGoal, &currentGoal, path);
            adjustPathAwayFromObstacles(path, map); // 调整路径点远离障碍物
            free(visitedStart);
            free(visitedGoal);
            freeQueue(&openStart);
            freeQueue(&openGoal);
            return true;
        }

        Point neighbors[8];
        int neighborCount;

        getNeighbors(currentStart.pos, neighbors, &neighborCount, map);
        for (int i = 0; i < neighborCount; i++) {
            Point neighbor = neighbors[i];
            Point jumpPoint;
            if (jump(currentStart.pos, (Point){neighbor.x - currentStart.pos.x, neighbor.y - currentStart.pos.y}, goal, map, &jumpPoint)) {
                if (!findNodeInList(jumpPoint, visitedStart, visitedStartSize)) {
                    Node neighborNode = { jumpPoint, &visitedStart[visitedStartSize - 1], currentStart.g + 1, heuristic(jumpPoint, goal), 0 };
                    neighborNode.f = neighborNode.g + neighborNode.h;
                    push(&openStart, neighborNode);
                }
            }
        }

        getNeighbors(currentGoal.pos, neighbors, &neighborCount, map);
        for (int i = 0; i < neighborCount; i++) {
            Point neighbor = neighbors[i];
            Point jumpPoint;
            if (jump(currentGoal.pos, (Point){neighbor.x - currentGoal.pos.x, neighbor.y - currentGoal.pos.y}, start, map, &jumpPoint)) {
                if (!findNodeInList(jumpPoint, visitedGoal, visitedGoalSize)) {
                    Node neighborNode = { jumpPoint, &visitedGoal[visitedGoalSize - 1], currentGoal.g + 1, heuristic(jumpPoint, start), 0 };
                    neighborNode.f = neighborNode.g + neighborNode.h;
                    push(&openGoal, neighborNode);
                }
            }
        }
    }

    printf("No path found.\n");
    free(visitedStart);
    free(visitedGoal);
    freeQueue(&openStart);
    freeQueue(&openGoal);

    return false;
}
/*
int main() {

    Point start = { MAP_SIZE - 1, 0 };
    Point goal = { 0, MAP_SIZE - 1 };

    Cluster path;
    initCluster(&path, MAP_SIZE * MAP_SIZE);

    if (bidirectionalJPS(map, start, goal, &path)) {
        printf("Path found:\n");
        for (int i = 0; i < path.size; i++) {
            printf("(%d, %d)\n", path.points[i].x, path.points[i].y);
        }
    } else {
        printf("No path found.\n");
    }

    freeCluster(&path);
  
    return 0;
}
*/