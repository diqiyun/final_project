#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <omp.h>
#include <time.h> 
#include "map.h"
#include "cluster.h"
#include "dbscan.h"
#include "path.h"

#define MAP_SIZE 30
#define SUBMAP_SIZE 10
#define NUM_SUBMAPS 9

typedef struct {
    Point start;
    Point goal;
} SubmapBounds;

void searchPathInSubmap(int thread_id, SubmapBounds bounds, Cluster* path);
void printClusterPath(const Cluster* cluster, const char* message);
int countTurns(const Cluster* cluster);
void writePathToCSV(const Cluster* cluster, const char* filename);

int main() {
    Cluster clusters[NUM_SUBMAPS];  
    SubmapBounds submapBounds[NUM_SUBMAPS];
    int numClusters = NUM_SUBMAPS;


    if (!identifyAndClusterObstacles(clusters, &numClusters)) {
        fprintf(stderr, "Obstacle clustering failed\n");
        return EXIT_FAILURE;
    }

    if (!markHotspots(clusters, numClusters)) {
        fprintf(stderr, "Hotspot marking failed\n");
        return EXIT_FAILURE;
    }

    // 初始化所有子地图的 start 和 goal
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            int index = i * 3 + j;
            submapBounds[index].start.x = (i + 1) * SUBMAP_SIZE - 1;
            submapBounds[index].start.y = j * SUBMAP_SIZE;
            submapBounds[index].goal.x = i * SUBMAP_SIZE;
            submapBounds[index].goal.y = (j + 1) * SUBMAP_SIZE - 1;
        }
    }

    // The submap on the diagonal
    submapBounds[6].start.x = 29; // C
    submapBounds[6].start.y = 0;
    submapBounds[6].goal.x = 20;
    submapBounds[6].goal.y = 9;

    submapBounds[4].start.x = 20; // B
    submapBounds[4].start.y = 9;
    submapBounds[4].goal.x = 9;
    submapBounds[4].goal.y = 20;

    submapBounds[2].start.x = 9; // A
    submapBounds[2].start.y = 20;
    submapBounds[2].goal.x = 0;
    submapBounds[2].goal.y = 29;


    for (int i = 0; i < NUM_SUBMAPS; i++) {
        initCluster(&clusters[i], 100); 
    }


    struct timespec start_time, end_time;
    clock_gettime(CLOCK_MONOTONIC, &start_time);


    #pragma omp parallel num_threads(NUM_SUBMAPS)
    {
        int thread_id = omp_get_thread_num();
        Cluster path;
        initCluster(&path, 100); // 初始化每个线程的局部 path 变量
        searchPathInSubmap(thread_id, submapBounds[thread_id], &path);


        #pragma omp critical
        {
            printf("Thread %d: Adding %d points to cluster\n", thread_id, path.size);
        }

        for (int i = 0; i < path.size; i++) {
            addPointToCluster(&clusters[thread_id], path.points[i]);
        }

        freeCluster(&path); //这只是释放堆上的 points 数组）
    }


    clock_gettime(CLOCK_MONOTONIC, &end_time);
    double elapsed_time = (end_time.tv_sec - start_time.tv_sec) + 
                          (end_time.tv_nsec - start_time.tv_nsec) / 1e9;

 
    printf("Path planning time: %.6f seconds\n", elapsed_time);


    printClusterPath(&clusters[6], "Path in submap C (from (29, 0) to (20, 9)):");
    printClusterPath(&clusters[4], "Path in submap B (from (20, 9) to (9, 20)):");
    printClusterPath(&clusters[2], "Path in submap A (from (9, 20) to (0, 29)):");


    int turnsC = countTurns(&clusters[6]);
    int turnsB = countTurns(&clusters[4]);
    int turnsA = countTurns(&clusters[2]);

    printf("Number of turns in submap C: %d\n", turnsC);
    printf("Number of turns in submap B: %d\n", turnsB);
    printf("Number of turns in submap A: %d\n", turnsA);

 
    writePathToCSV(&clusters[6], "C.csv");
    writePathToCSV(&clusters[4], "B.csv");
    writePathToCSV(&clusters[2], "A.csv");


    for (int i = 0; i < NUM_SUBMAPS; i++) {
        freeCluster(&clusters[i]); 
    }

    return 0;
}

void searchPathInSubmap(int thread_id, SubmapBounds bounds, Cluster* path) {
    Point start = bounds.start;
    Point goal = bounds.goal;


    #pragma omp critical
    {
        printf("Thread %d: Searching path from (%d, %d) to (%d, %d)\n", 
               thread_id, start.x, start.y, goal.x, goal.y);
    }

    if (!bidirectionalJPS(map, start, goal, path)) {
        #pragma omp critical
        {
            fprintf(stderr, "JPS failed in thread %d\n", thread_id);
        }
    } else {
        #pragma omp critical
        {
            printf("Thread %d: Path found with %d points\n", thread_id, path->size);
        }
    }
}

void printClusterPath(const Cluster* cluster, const char* message) {
    printf("%s:\n", message);
    for (int i = 0; i < cluster->size; i++) {
        // 输出调整后的坐标，中心对齐
        double centerX = cluster->points[i].x + 0.5;
        double centerY = cluster->points[i].y + 0.5;
        printf("(%.1f, %.1f)\n", centerX, centerY);
    }
}


int countTurns(const Cluster* cluster) {
    if (cluster->size < 3) return 0; 
    int turnCount = 0;
    for (int i = 1; i < cluster->size - 1; i++) {
        Point prev = cluster->points[i - 1];
        Point curr = cluster->points[i];
        Point next = cluster->points[i + 1];

        int dx1 = curr.x - prev.x;
        int dy1 = curr.y - prev.y;
        int dx2 = next.x - curr.x;
        int dy2 = next.y - curr.y;

     
        if (dx1 != dx2 || dy1 != dy2) {
            turnCount++;
        }
    }

    return turnCount;
}


void writePathToCSV(const Cluster* cluster, const char* filename) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        fprintf(stderr, "Failed to open file %s for writing\n", filename);
        return;
    }

    fprintf(file, "x,y\n"); 
    for (int i = 0; i < cluster->size; i++) {
        double centerX = cluster->points[i].x + 0.5;
        double centerY = cluster->points[i].y + 0.5;
        fprintf(file, "%.1f,%.1f\n", centerX, centerY);
    }

    fclose(file);
}
