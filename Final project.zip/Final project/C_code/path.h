#ifndef PATH_H
#define PATH_H

#include "map.h"
#include "cluster.h"

typedef struct Node {
    Point pos;
    struct Node* parent;
    double g; 
    double h; 
    double f; 
} Node;


typedef struct {
    Node* nodes;
    int size;
    int capacity;
} PriorityQueue;


void initQueue(PriorityQueue* queue, int capacity);


void push(PriorityQueue* queue, Node node);

Node pop(PriorityQueue* queue);


bool isEmpty(PriorityQueue* queue);

double heuristic(Point a, Point b);


bool isInBounds(Point p);


bool isInList(Point p, Node* list, int listSize);


void getNeighbors(Point p, Point* neighbors, int* count);


bool bidirectionalJPS(int map[MAP_SIZE][MAP_SIZE], Point start, Point goal, Cluster* path);

#endif // PATH_H