#ifndef DBSCAN_H
#define DBSCAN_H
#include <stdbool.h>
#include "cluster.h"  

bool identifyAndClusterObstacles(Cluster *clusters, int *numClusters);
bool markHotspots(Cluster *clusters, int numClusters);

#endif // DBSCAN_H