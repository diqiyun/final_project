#ifndef MAP_H
#define MAP_H

#define MAP_SIZE 30
extern int map[MAP_SIZE][MAP_SIZE];

#endif

